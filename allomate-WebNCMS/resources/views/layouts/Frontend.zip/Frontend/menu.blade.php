<div id="topHeader" class="topheader">

		<div class="container-fluid">
			<div class="row">
				<div class="col-12 navbar-top">

					<div class="row">
						<div class="col-lg-12 col-md-12">
							<nav class="navbar navbar-expand-lg">

								<div class="collapse navbar-collapse" id="navbarNavDropdown">
									<ul class="navbar-nav">
										<li class="nav-item">
											<a class="nav-link" href="#">Contact <span> ▸</span></a>
										</li>
										<li class="nav-item">
											<a class="nav-link" href="#">Our Team <span>▸</span></a>
										</li>
										<li class="nav-item top-contact">
											<a class="nav-link phone-no" href="#"><i class="fa fa-phone"></i>
												647-643-5426</a>
										</li>
									</ul>
								</div>
							</nav>
						</div>

					</div>
				</div>
				<div class="col-12">
					<div class="khanllp"><a href="index.html"><img alt="" src="images/khan-law.png"></a> </div>
					<a id="nav-toggle" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation"><span></span></a>
					<a href="#" class="mob-phone-no"><i class="fa fa-phone"></i>
						647-643-5426</a>
					<nav class="navbar navbar-expand-lg">
						<div class="collapse navbar-collapse" id="navbarNavDropdown">
							<ul class="navbar-nav">
								<li class="nav-item"><a class="nav-link" href="{{route('home')}}">Home <span class="sr-only">(current)</span></a></li>
								<li class="nav-item">
									<a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Pages
									</a>
									<div class="dropdown-menu">
										<a class="dropdown-item" href="services-page-sections.html">Services page </a>
										<a class="dropdown-item" href="form-page.html">Form page</a>
										<a class="dropdown-item" href="blogs-list.html">Blogs list</a>
										<a class="dropdown-item" href="blogs-detail.html">Blog detail</a>
										<a class="dropdown-item" href="#">Real estate, Family law, and Wills +
											estates</a>
									</div>
								</li>

								<li class="nav-item"><a class="nav-link" href="{{route('aboutus')}}">Who we are</a></li>
								<li class="nav-item"><a class="nav-link" href="what-we-do.html">What we do</a></li>
								<li class="nav-item"><a class="nav-link" href="the-difference.html">The difference</a>
								</li>
								<li class="nav-item"><a class="nav-link" href="get-in-touch.html">Get in touch</a></li>
							</ul>
						</div>
					</nav>
				</div>

			</div>
		</div>

	</div>
