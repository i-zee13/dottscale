<div class="Footer">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-md-6 col-sm-12">
						<img class="F-Logo" src="images/khan-law.png" alt="" />
						<p>Khan Law is a boutique law practice that has been providing legal services to the Greater
							Toronto Area since the year 2000.</p>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-12">
						<ul>
							<li><a href="#">Home</a></li>
							<li><a href="#">Who we are</a></li>
							<li><a href="#">What we do</a></li>
							<li><a href="#">The difference</a></li>
							<li><a href="#">Community</a></li>
							<li><a href="#">News</a></li>
						</ul>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-12">
						<ul>
							<li><a href="#">Contact Us</a></li>
							<li><a href="#">Privacy Policy</a></li>
							<li><a href="#">Terms of Use</a></li>
						</ul>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-12">
						<h4>Contact Info</h4>
						<p class="f-phone">647-643-5426</p>
						<a class="emailto" href="mailto:info@khanllp.com">info@khanllp.com</a>
						<p>MILTON <span class="org-color">&nbsp;|&nbsp;</span> MISSISSAUGA <span
								class="org-color">&nbsp;|&nbsp;</span> TORONTO</p>

						<div class="social-f">
							<a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
							<a href="#" target="_blank"><i class="fa fa-linkedin"></i></a>
						</div>
					</div>
				</div>
			</div>
			<div class="copy-right">
				<div class="container">
					<div class="row">
						<div class="col-md-6 ">Copyright © 2020 khanllp.com All Rights Reserved.</div>
						<div class="col-md-6 developed">
							<a class="m-0" target="_blank" href="https://www.allomate.com">Developed By Allomate
								Solutions.</a>
						</div>
					</div>
				</div>
			</div>
		</div>